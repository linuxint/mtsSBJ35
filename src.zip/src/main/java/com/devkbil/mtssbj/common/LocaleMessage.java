package com.devkbil.mtssbj.common;

import lombok.RequiredArgsConstructor;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;

import java.util.Locale;

/**
 * LocaleMessage is a configuration class responsible for retrieving localized messages
 * from the application's MessageSource based on a specified locale and message key.
 * It provides methods to fetch messages with or without additional arguments.
 */
@Configuration
@RequiredArgsConstructor
public class LocaleMessage {

    MessageSource messageSource;

    /**
     * Retrieves a localized message from the application's message source using the specified key.
     *
     * @param key the key for the desired message
     * @return the localized message corresponding to the provided key in the Korean locale
     */
    public String getMessage(String key) {
        return messageSource.getMessage(key, null, Locale.KOREA);
    }

    /**
     * Retrieves a localized message using the specified key and optional arguments.
     *
     * @param key  the key for the desired message
     * @param objs an array of objects to be filled in for placeholders within the message
     * @return the localized message corresponding to the provided key and arguments
     */
    public String getMessage(String key, Object[] objs) {
        return messageSource.getMessage(key, objs, Locale.getDefault());
    }
}
