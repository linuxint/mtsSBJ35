package com.devkbil.mtssbj.common;

import com.devkbil.mtssbj.common.util.DateLegacy;

import org.springframework.format.Formatter;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * {@link LocalDate} 타입의 포매터 구현으로, 특정 패턴을 사용하여 날짜를
 * 파싱하고 출력할 수 있도록 지원합니다.
 * <p>
 * 이 포매터는 {@code DateLegacy.getYyyyMMdd_bar()} 메서드에서 제공하는
 * 사전 정의된 패턴을 사용하며, 날짜 조작에 {@link Locale} 매개변수를 사용할 수 있습니다.
 * <p>
 * {@link Formatter} 인터페이스를 구현하여 {@link String} 표현과 {@link LocalDate} 객체 간
 * 변환을 지원합니다.
 */
public class LocalDateFormatter implements Formatter<LocalDate> {

    /**
     * 텍스트 형식의 날짜를 사전 정의된 패턴으로 {@link LocalDate} 객체로 변환합니다.
     *
     * @param text   변환할 날짜 문자열
     * @param locale 파싱 시 사용될 로케일 (현재 구현에서는 명시적으로 사용되지 않음)
     * @return 입력된 문자열로부터 변환된 {@link LocalDate}
     * @throws ParseException 문자열을 유효한 {@link LocalDate}로 변환할 수 없는 경우 발생
     */
    @Override
    public LocalDate parse(String text, Locale locale) throws ParseException {
        return LocalDate.parse(text, DateTimeFormatter.ofPattern(DateLegacy.getYyyyMMdd_bar()));
    }

    /**
     * {@link LocalDate} 객체를 사전 정의된 패턴을 사용하여 {@link String} 형식으로 변환합니다.
     *
     * @param object 포맷팅할 {@link LocalDate} 객체
     * @param locale 포맷팅 시 사용될 로케일 (현재 구현에서는 명시적으로 사용되지 않음)
     * @return 포맷팅된 날짜 문자열
     */
    @Override
    public String print(LocalDate object, Locale locale) {
        return DateTimeFormatter.ofPattern(DateLegacy.getYyyyMMdd_bar()).format(object);
    }
}
