package com.devkbil.mtssbj.common;

/**
 * Excel 파일 생성 및 내보내기와 관련된 상수들을 정의하는 클래스입니다.
 * 메모리 사용량 제한, 엑셀 파일 구성에 필요한 키 값들을 포함합니다.
 */
public class ExcelConstant {
    /** 메모리에 저장할 최대 행 수 (100개). 이 수를 초과하면 디스크에 자동으로 플러시됩니다. */
    public static final int MAX_ROW_COUNT = 100;

    /** 엑셀 파일의 헤더 정보를 저장하는 키 이름 */
    public static final String HEADER_KEY_NAME = "header";

    /** 엑셀 파일에 출력할 데이터 목록을 저장하는 키 이름 */
    public static final String DATA_KEY_NAME = "listview";

    /** 엑셀 시트의 이름을 저장하는 키 이름 */
    public static final String SHEET_KEY_NAME = "sheetname";
}
