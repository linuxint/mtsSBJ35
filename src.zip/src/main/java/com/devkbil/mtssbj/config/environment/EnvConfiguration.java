package com.devkbil.mtssbj.config.environment;

/**
 * 환경별 구성을 나타내는 인터페이스.
 * 이 인터페이스는 메시지나 캐싱 메커니즘과 같은 환경별 구성을
 * 검색하기 위한 메서드를 제공합니다.
 */
public interface EnvConfiguration {

    /**
     * 현재 환경 프로필에 특정한 메시지를 검색합니다.
     *
     * @return 활성화된 환경 프로필과 연결된 메시지
     */
    String getMessage();

    /**
     * 현재 환경 프로필에 특정한 캐시 구성을 검색합니다.
     *
     * @return 활성화된 환경 프로필과 연결된 캐시 구성
     */
    String cache();
}
