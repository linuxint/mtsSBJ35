package com.devkbil.mtssbj.config;

/**
 * This class defines configuration constants used throughout the application.
 * It provides a set of predefined values for cookie expiration, URL paths,
 * HTTP parameters, session and cookie names, as well as a list of
 * URL patterns that are allowed without authentication or authorization.
 */
public class ConfigConstant {

    /** 쿠키 만료 시간 (초 단위, 기본값: 30일) */
    public static final int COOKIE_EXPIRE = 60 * 60 * 24 * 30;

    /** 접근 거부 시 리다이렉트될 URL 경로 */
    public static final String URL_ACCESS_DENIED = "/accessDenied";

    /** 자동 로그인을 위한 "remember me" 파라미터 이름 */
    public static final String PARAMETER_REMEMBER_ME = "remember-me";

    /** HTTP 세션 ID 쿠키 이름 */
    public static final String JSESSIONID = "JSESSIONID";

    /** 사용자 세션 ID 쿠키 이름 */
    public static final String SID_COOKIE_NAME = "sid";

    /** 자동 로그인 기능을 위한 "remember me" 쿠키 이름 */
    public static final String REMEMBER_ME_COOKIE_NAME = "mtsSBJ3-remember-me";

    /** 자동 로그인 기능에서 사용되는 보안 키 */
    public static final String REMEMBER_ME_KEY = "remember-me-key";

    /** 메인 페이지 URL 경로 */
    public static final String URL_MAIN = "/index";

    /** 로그인 페이지 URL 경로 */
    public static final String URL_LOGIN = "/memberLogin";

    /** 로그인 처리 URL 경로 */
    public static final String URL_LOGIN_PROCESS = "/login-process";

    /** 에러 페이지 URL 패턴 */
    public static final String URL_ERROR = "/error/**";

    /** 로그아웃 URL 경로 */
    public static final String URL_LOGOUT = "/memberLogout";

    /** 에러 페이지 템플릿 경로 */
    public static final String CLASSPATH_ERROR_PAGE = "classpath:templates/error/";
    //    public static final String CLASSPATH_CSS = "classpath:/static/css/";
    //    public static final String CLASSPATH_IMAGES = "classpath:/static/images/";
    //    public static final String CLASSPATH_JS = "classpath:/static/js/";

    //    public static final String RESOURCES_JS = "resources/js/**";
    //    public static final String RESOURCES_IMAGES = "resources/images/**";
    //    public static final String RESOURCES_CSS = "resources/css/**";

    /** 로그인 요청 시 사용되는 사용자 ID 파라미터 이름 */
    public static final String PARAMETER_LOGIN_ID = "userid";

    /** 로그인 요청 시 사용되는 비밀번호 파라미터 이름 */
    public static final String PARAMETER_LOGIN_PWD = "userpw";

    /**
     * A list of predefined URL patterns that can be accessed without requiring authentication
     * or authorization. These are typically used to define public or unrestricted access routes
     * within the security configuration of the application.
     *
     * The list includes paths for monitoring, authentication APIs, static resources
     * (CSS, JavaScript, images), and specific endpoints like login, logout, and error pages.
     * Use this array to configure security settings where specific paths need to be excluded
     * from access restrictions.
     */
    public static final String[] allAllowList = {
        "/actuator/**",
        "/api/monitor/**", // MonitorSecurityConfig 대신해서 코드추가
        "/api/v1/auth/**",
        "/css/**",
        "/js/**",
        "/images/**",
        "/favicon.ico",
        "/memberLogout",
        "/memberLogin",
        "/login-process",
        "/memberLoginChk",
        "/error/**"
    };
}
