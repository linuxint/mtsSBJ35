package com.devkbil.mtssbj.error;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * [공통 코드] API 통신에 대한 '에러 코드'를 Enum 형태로 관리를 한다.
 * Global Error CodeList : 전역으로 발생하는 에러코드를 관리한다.
 * Custom Error CodeList : 업무 페이지에서 발생하는 에러코드를 관리한다
 * Error Code Constructor : 에러코드를 직접적으로 사용하기 위한 생성자를 구성한다.
 *
 * @author lee
 */
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public enum ErrorCode {

    /**
     * ******************************* Global Error CodeList ***************************************
     * HTTP Status Code
     * 400 : Bad Request
     * 401 : Unauthorized
     * 403 : Forbidden
     * 404 : Not Found
     * 500 : Internal Server Error
     * *********************************************************************************************
     */
    /** 잘못된 서버 요청이 발생한 경우 */
    BAD_REQUEST_ERROR(400, "G001", "Bad Request Exception"),

    /** 모델 속성 데이터가 요청 본문에 존재하지 않는 경우 */
    REQUEST_BODY_MISSING_ERROR(400, "G002", "Required request body is missing"),

    /** 요청된 데이터의 타입이 유효하지 않은 경우 */
    INVALID_TYPE_VALUE(400, "G003", " Invalid Type Value"),

    /** Request Parameter로 데이터가 전달되지 않은 경우 */
    MISSING_REQUEST_PARAMETER_ERROR(400, "G004", "Missing Servlet RequestParameter Exception"),

    /** 입력/출력 작업 중 오류가 발생한 경우 */
    IO_ERROR(400, "G005", "I/O Exception"),

    /** com.google.gson을 사용한 JSON 파싱 중 실패한 경우 */
    JSON_PARSE_ERROR(400, "G006", "JsonParseException"),

    /** com.fasterxml.jackson.core 처리 중 오류가 발생한 경우 */
    JACKSON_PROCESS_ERROR(400, "G007", "com.fasterxml.jackson.core Exception"),

    /** 인증되지 않은 사용자의 요청인 경우 */
    UNAUTHORIZED_ERROR(401, "G401", "Unauthorized Exception"),

    /** 요청한 리소스에 대한 접근 권한이 없는 경우 */
    FORBIDDEN_ERROR(403, "G008", "Forbidden Exception"),

    /** 요청한 리소스가 서버에 존재하지 않는 경우 */
    NOT_FOUND_ERROR(404, "G009", "Not Found Exception"),

    /** Null Point Exception이 발생한 경우 */
    NULL_POINT_ERROR(404, "G010", "Null Point Exception"),

    /** 요청 파라미터 또는 경로 변수의 유효성 검사 실패 시 */
    NOT_VALID_ERROR(404, "G011", "handle Validation Exception"),

    /** HTTP 헤더에 필요한 데이터가 존재하지 않는 경우 */
    NOT_VALID_HEADER_ERROR(404, "G012", "Header에 데이터가 존재하지 않는 경우 "),

    /** 서버에서 처리할 수 없는 내부 오류가 발생한 경우 */
    INTERNAL_SERVER_ERROR(500, "G999", "Internal Server Error Exception"),


    /**
     * ******************************* Custom Error CodeList ***************************************
     */
    /** 데이터베이스 INSERT 트랜잭션 실행 중 오류가 발생한 경우 */
    INSERT_ERROR(200, "9999", "Insert Transaction Error Exception"),

    /** 데이터베이스 UPDATE 트랜잭션 실행 중 오류가 발생한 경우 */
    UPDATE_ERROR(200, "9999", "Update Transaction Error Exception"),

    /** 데이터베이스 DELETE 트랜잭션 실행 중 오류가 발생한 경우 */
    DELETE_ERROR(200, "9999", "Delete Transaction Error Exception"),

    /** 비즈니스 로직 처리 중 예외가 발생한 경우 */
    BUSINESS_EXCEPTION_ERROR(200, "B999", "Business Exception Error");

    /**
     * ******************************* Error Code Constructor ***************************************
     */
    // 에러 코드의 '코드 상태'을 반환한다.
    private int status;

    // 에러 코드의 '코드간 구분 값'을 반환한다.
    private String divisionCode;

    // 에러 코드의 '코드 메시지'을 반환한다.
    private String message;

    // 생성자 구성
    ErrorCode(int status, String divisionCode, String message) {
        this.status = status;
        this.divisionCode = divisionCode;
        this.message = message;
    }
}
