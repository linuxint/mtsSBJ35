package com.devkbil.mtssbj;

public class EnumPortTest {

    public static void main(String[] args) {

        String divCode = "02";

        System.out.println(EnumPort.getBwcdOfPort(divCode));
    }
}
