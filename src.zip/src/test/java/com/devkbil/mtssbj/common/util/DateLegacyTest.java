package com.devkbil.mtssbj.common.util;

import com.devkbil.mtssbj.schedule.DateVO;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DateLegacy 유틸리티 클래스에 대한 단위 테스트
 */
class DateLegacyTest {

    @Test
    void testGetYyyyMMdd_bar() {
        String result = DateLegacy.getYyyyMMdd_bar();
        assertNotNull(result);
        assertTrue(result.matches("\\d{4}-\\d{2}-\\d{2}"));
    }

    @Test
    void testGetToday() {
        Date result = DateLegacy.getToday();
        assertNotNull(result);
        LocalDate today = LocalDate.now();
        LocalDate resultDate = result.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(today, resultDate);
    }

    @Test
    void testConvDate() {
        Date date = DateLegacy.convDate("2023-12-25");
        assertNotNull(date);
        LocalDate localDate = date.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(2023, localDate.getYear());
        assertEquals(12, localDate.getMonthValue());
        assertEquals(25, localDate.getDayOfMonth());

        assertNull(DateLegacy.convDate("invalid-date"));
        assertNull(DateLegacy.convDate(null));
        assertNull(DateLegacy.convDate(""));
    }

    @Test
    void testConvDateWithFormat() {
        Date date = DateLegacy.convDate("20231225", "yyyyMMdd");
        assertNotNull(date);
        LocalDate localDate = date.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(2023, localDate.getYear());
        assertEquals(12, localDate.getMonthValue());
        assertEquals(25, localDate.getDayOfMonth());

        assertNull(DateLegacy.convDate("invalid-date", "yyyyMMdd"));
        assertNull(DateLegacy.convDate(null, "yyyyMMdd"));
        assertNull(DateLegacy.convDate("", "yyyyMMdd"));
    }

    @Test
    void testGetYearAndMonth() {
        Date date = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        assertEquals(2023, DateLegacy.getYear(date));
        assertEquals(12, DateLegacy.getMonth(date));

        assertEquals(0, DateLegacy.getYear(null));
        assertEquals(0, DateLegacy.getMonth(null));
    }

    @Test
    void testDate2Str() {
        Date date = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        assertEquals("2023-12-25", DateLegacy.date2Str(date));
        assertNull(DateLegacy.date2Str(null));
    }

    @Test
    void testStr2DateAndStringToDate() {
        Date date = DateLegacy.str2Date("2023-12-25");
        assertNotNull(date);
        LocalDate localDate = date.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(2023, localDate.getYear());
        assertEquals(12, localDate.getMonthValue());
        assertEquals(25, localDate.getDayOfMonth());

        assertEquals(date, DateLegacy.stringToDate("2023-12-25"));

        assertNull(DateLegacy.str2Date("invalid-date"));
        assertNull(DateLegacy.str2Date(null));
        assertNull(DateLegacy.str2Date(""));
    }

    @Test
    void testGetWeekOfMonth() {
        Date date = Date.from(LocalDate.of(2023, 12, 1).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        assertEquals(1, DateLegacy.getWeekOfMonth(date));

        date = Date.from(LocalDate.of(2023, 12, 31).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        assertEquals(5, DateLegacy.getWeekOfMonth(date));

        assertEquals(0, DateLegacy.getWeekOfMonth(null));
    }

    @Test
    void testGetFirstAndLastOfWeek() {
        Date monday = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        Date sunday = Date.from(LocalDate.of(2023, 12, 31).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());

        Date firstOfWeek = DateLegacy.getFirstOfWeek(monday);
        Date lastOfWeek = DateLegacy.getLastOfWeek(monday);

        assertNotNull(firstOfWeek);
        assertNotNull(lastOfWeek);
        assertEquals(monday, firstOfWeek);
        assertEquals(sunday, lastOfWeek);

        assertNull(DateLegacy.getFirstOfWeek(null));
        assertNull(DateLegacy.getLastOfWeek(null));
    }

    @Test
    void testDateAdd() {
        Date date = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        
        Date future = DateLegacy.dateAdd(date, 3);
        assertNotNull(future);
        LocalDate futureDate = future.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(LocalDate.of(2023, 12, 28), futureDate);

        Date past = DateLegacy.dateAdd(date, -3);
        assertNotNull(past);
        LocalDate pastDate = past.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(LocalDate.of(2023, 12, 22), pastDate);

        assertNull(DateLegacy.dateAdd(null, 1));
    }

    @Test
    void testGetDayOfWeek() {
        Date monday = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        assertEquals(1, DateLegacy.getDayOfWeek(monday));

        Date sunday = Date.from(LocalDate.of(2023, 12, 31).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        assertEquals(7, DateLegacy.getDayOfWeek(sunday));

        assertEquals(0, DateLegacy.getDayOfWeek(null));
    }

    @Test
    void testDate2VO() {
        Date date = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        DateVO vo = DateLegacy.date2VO(date);

        assertNotNull(vo);
        assertEquals(2023, vo.getYear());
        assertEquals(12, vo.getMonth());
        assertEquals(25, vo.getDay());
        assertEquals("2023-12-25", vo.getDate());
        assertNotNull(vo.getWeek());

        assertNull(DateLegacy.date2VO(null));
    }

    @Test
    void testDateDiff() {
        Date date1 = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());
        Date date2 = Date.from(LocalDate.of(2023, 12, 28).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());

        assertEquals(3, DateLegacy.dateDiff(date1, date2));
        assertEquals(-3, DateLegacy.dateDiff(date2, date1));
        assertEquals(0, DateLegacy.dateDiff(null, date2));
        assertEquals(0, DateLegacy.dateDiff(date1, null));
        assertEquals(0, DateLegacy.dateDiff(null, null));
    }

    @Test
    void testSafeStr2Date() {
        Date date = DateLegacy.safeStr2Date("2023-12-25");
        assertNotNull(date);
        LocalDate localDate = date.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(2023, localDate.getYear());
        assertEquals(12, localDate.getMonthValue());
        assertEquals(25, localDate.getDayOfMonth());

        assertNull(DateLegacy.safeStr2Date("invalid-date"));
        assertNull(DateLegacy.safeStr2Date(null));
        assertNull(DateLegacy.safeStr2Date(""));
    }

    @Test
    void testDateAddMonth() {
        Date date = Date.from(LocalDate.of(2023, 12, 25).atStartOfDay(DateCore.SYSTEM_ZONE_ID).toInstant());

        Date future = DateLegacy.dateAddMonth(date, 3);
        assertNotNull(future);
        LocalDate futureDate = future.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(LocalDate.of(2024, 3, 25), futureDate);

        Date past = DateLegacy.dateAddMonth(date, -3);
        assertNotNull(past);
        LocalDate pastDate = past.toInstant().atZone(DateCore.SYSTEM_ZONE_ID).toLocalDate();
        assertEquals(LocalDate.of(2023, 9, 25), pastDate);

        assertNull(DateLegacy.dateAddMonth(null, 1));
    }
}