package com.devkbil.mtssbj.common.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DateCore 유틸리티 클래스에 대한 단위 테스트
 */
class DateCoreTest {

    @Test
    void testGetCurrentDate() {
        LocalDate result = DateCore.getCurrentDate();
        assertNotNull(result);
        assertEquals(LocalDate.now(), result);
    }

    @Test
    void testGetCurrentDateTime() {
        LocalDateTime result = DateCore.getCurrentDateTime();
        assertNotNull(result);
        // Due to millisecond differences, we compare only up to minutes
        LocalDateTime now = LocalDateTime.now();
        assertEquals(now.getYear(), result.getYear());
        assertEquals(now.getMonth(), result.getMonth());
        assertEquals(now.getDayOfMonth(), result.getDayOfMonth());
        assertEquals(now.getHour(), result.getHour());
        assertEquals(now.getMinute(), result.getMinute());
    }

    @Test
    void testGetCurrentTime() {
        LocalTime result = DateCore.getCurrentTime();
        assertNotNull(result);
        // Due to millisecond differences, we compare only up to minutes
        LocalTime now = LocalTime.now();
        assertEquals(now.getHour(), result.getHour());
        assertEquals(now.getMinute(), result.getMinute());
    }

    @Test
    void testConstants() {
        assertEquals("yyyy-MM-dd", DateCore.DEFAULT_DATE_FORMAT);
        assertEquals("yyyy-MM-dd HH:mm:ss", DateCore.DEFAULT_DATETIME_FORMAT);
        assertNotNull(DateCore.DEFAULT_LOCALE);
        assertNotNull(DateCore.DEFAULT_DATE_FORMATTER);
        assertNotNull(DateCore.DEFAULT_DATETIME_FORMATTER);
        assertNotNull(DateCore.SYSTEM_ZONE_ID);
    }
}