package com.devkbil.mtssbj.common.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DateConverter 유틸리티 클래스에 대한 단위 테스트
 */
class DateConverterTest {

    @Test
    void testParseDate() {
        LocalDate date = DateConverter.parseDate("2023-12-25");
        assertNotNull(date);
        assertEquals(2023, date.getYear());
        assertEquals(12, date.getMonthValue());
        assertEquals(25, date.getDayOfMonth());

        assertNull(DateConverter.parseDate("invalid-date"));
        assertNull(DateConverter.parseDate(null));
        assertNull(DateConverter.parseDate(""));
    }

    @Test
    void testParseDateWithFormat() {
        LocalDate date = DateConverter.parseDate("20231225", "yyyyMMdd");
        assertNotNull(date);
        assertEquals(2023, date.getYear());
        assertEquals(12, date.getMonthValue());
        assertEquals(25, date.getDayOfMonth());

        assertNull(DateConverter.parseDate("invalid-date", "yyyyMMdd"));
        assertNull(DateConverter.parseDate(null, "yyyyMMdd"));
        assertNull(DateConverter.parseDate("", "yyyyMMdd"));
        assertNull(DateConverter.parseDate("20231225", null));
        assertNull(DateConverter.parseDate("20231225", ""));
    }

    @Test
    void testParseDateTime() {
        LocalDateTime dateTime = DateConverter.parseDateTime("2023-12-25 15:30:45");
        assertNotNull(dateTime);
        assertEquals(2023, dateTime.getYear());
        assertEquals(12, dateTime.getMonthValue());
        assertEquals(25, dateTime.getDayOfMonth());
        assertEquals(15, dateTime.getHour());
        assertEquals(30, dateTime.getMinute());
        assertEquals(45, dateTime.getSecond());

        assertNull(DateConverter.parseDateTime("invalid-datetime"));
        assertNull(DateConverter.parseDateTime(null));
        assertNull(DateConverter.parseDateTime(""));
    }

    @Test
    void testParseDateTimeWithFormat() {
        LocalDateTime dateTime = DateConverter.parseDateTime("20231225153045", "yyyyMMddHHmmss");
        assertNotNull(dateTime);
        assertEquals(2023, dateTime.getYear());
        assertEquals(12, dateTime.getMonthValue());
        assertEquals(25, dateTime.getDayOfMonth());
        assertEquals(15, dateTime.getHour());
        assertEquals(30, dateTime.getMinute());
        assertEquals(45, dateTime.getSecond());

        assertNull(DateConverter.parseDateTime("invalid-datetime", "yyyyMMddHHmmss"));
        assertNull(DateConverter.parseDateTime(null, "yyyyMMddHHmmss"));
        assertNull(DateConverter.parseDateTime("", "yyyyMMddHHmmss"));
        assertNull(DateConverter.parseDateTime("20231225153045", null));
        assertNull(DateConverter.parseDateTime("20231225153045", ""));
    }

    @Test
    void testFormatDate() {
        LocalDate date = LocalDate.of(2023, 12, 25);
        assertEquals("2023-12-25", DateConverter.formatDate(date));
        assertEquals("20231225", DateConverter.formatDate(date, "yyyyMMdd"));

        assertNull(DateConverter.formatDate(null));
        assertNull(DateConverter.formatDate(date, null));
        assertNull(DateConverter.formatDate(date, ""));
    }

    @Test
    void testFormatDateTime() {
        LocalDateTime dateTime = LocalDateTime.of(2023, 12, 25, 15, 30, 45);
        assertEquals("2023-12-25 15:30:45", DateConverter.formatDateTime(dateTime));
        assertEquals("20231225153045", DateConverter.formatDateTime(dateTime, "yyyyMMddHHmmss"));

        assertNull(DateConverter.formatDateTime(null));
        assertNull(DateConverter.formatDateTime(dateTime, null));
        assertNull(DateConverter.formatDateTime(dateTime, ""));
    }
}