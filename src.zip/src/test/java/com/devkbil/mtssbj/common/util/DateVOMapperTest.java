package com.devkbil.mtssbj.common.util;

import com.devkbil.mtssbj.schedule.DateVO;
import com.devkbil.mtssbj.schedule.MonthVO;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DateVOMapper 유틸리티 클래스에 대한 단위 테스트
 */
class DateVOMapperTest {

    @Test
    void testToDateVO() {
        LocalDate date = LocalDate.of(2023, 12, 25);
        DateVO vo = DateVOMapper.toDateVO(date);

        assertNotNull(vo);
        assertEquals(2023, vo.getYear());
        assertEquals(12, vo.getMonth());
        assertEquals(25, vo.getDay());
        assertEquals("2023-12-25", vo.getDate());
        assertNotNull(vo.getWeek());
        assertFalse(vo.isIstoday()); // Assuming test is not run on 2023-12-25

        assertNull(DateVOMapper.toDateVO(null));
    }

    @Test
    void testToMonthVO() {
        LocalDate date = LocalDate.of(2023, 12, 25);
        MonthVO vo = DateVOMapper.toMonthVO(date);

        assertNotNull(vo);
        assertEquals("2023", vo.getYear());
        assertEquals("12", vo.getMonth());

        // Test single digit month
        MonthVO vo2 = DateVOMapper.toMonthVO(LocalDate.of(2023, 1, 1));
        assertEquals("01", vo2.getMonth());

        assertNull(DateVOMapper.toMonthVO(null));
    }

    @Test
    void testToLocalDate() {
        MonthVO vo = new MonthVO();
        vo.setYear("2023");
        vo.setMonth("12");

        LocalDate date = DateVOMapper.toLocalDate(vo);
        assertNotNull(date);
        assertEquals(2023, date.getYear());
        assertEquals(12, date.getMonthValue());
        assertEquals(1, date.getDayOfMonth()); // First day of month

        // Test invalid month handling
        vo.setMonth("13");
        date = DateVOMapper.toLocalDate(vo);
        assertNotNull(date);
        assertEquals(2024, date.getYear());
        assertEquals(1, date.getMonthValue());

        vo.setMonth("0");
        date = DateVOMapper.toLocalDate(vo);
        assertNotNull(date);
        assertEquals(2022, date.getYear());
        assertEquals(12, date.getMonthValue());

        // Test null and invalid inputs
        assertNull(DateVOMapper.toLocalDate(null));
        vo.setYear(null);
        assertNull(DateVOMapper.toLocalDate(vo));
        vo.setYear("");
        assertNull(DateVOMapper.toLocalDate(vo));
        vo.setYear("2023");
        vo.setMonth(null);
        assertNull(DateVOMapper.toLocalDate(vo));
        vo.setMonth("");
        assertNull(DateVOMapper.toLocalDate(vo));
    }

    @Test
    void testMonthValid() {
        MonthVO vo = new MonthVO();
        vo.setYear("2023");
        vo.setMonth("12");

        MonthVO result = DateVOMapper.monthValid(vo);
        assertNotNull(result);
        assertEquals("2023", result.getYear());
        assertEquals("12", result.getMonth());

        // Test month overflow
        vo.setMonth("13");
        result = DateVOMapper.monthValid(vo);
        assertNotNull(result);
        assertEquals("2024", result.getYear());
        assertEquals("01", result.getMonth());

        // Test month underflow
        vo.setMonth("0");
        result = DateVOMapper.monthValid(vo);
        assertNotNull(result);
        assertEquals("2022", result.getYear());
        assertEquals("12", result.getMonth());

        // Test null and invalid inputs
        assertNull(DateVOMapper.monthValid(null));
        vo.setYear("invalid");
        assertNull(DateVOMapper.monthValid(vo));
        vo.setMonth("invalid");
        assertNull(DateVOMapper.monthValid(vo));
    }
}
