package com.devkbil.mtssbj.common.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DateCalculator 유틸리티 클래스에 대한 단위 테스트
 */
class DateCalculatorTest {

    @Test
    void testDaysBetween() {
        LocalDate date1 = LocalDate.of(2023, 12, 25);
        LocalDate date2 = LocalDate.of(2023, 12, 28);

        assertEquals(3, DateCalculator.daysBetween(date1, date2));
        assertEquals(-3, DateCalculator.daysBetween(date2, date1));
    }

    @Test
    void testAddDays() {
        LocalDate date = LocalDate.of(2023, 12, 25);

        assertEquals(LocalDate.of(2023, 12, 28), DateCalculator.addDays(date, 3));
        assertEquals(LocalDate.of(2023, 12, 22), DateCalculator.addDays(date, -3));
    }

    @Test
    void testAddMonths() {
        LocalDate date = LocalDate.of(2023, 12, 25);

        assertEquals(LocalDate.of(2024, 3, 25), DateCalculator.addMonths(date, 3));
        assertEquals(LocalDate.of(2023, 9, 25), DateCalculator.addMonths(date, -3));
    }

    @Test
    void testGetFirstDayOfWeek() {
        // Monday
        LocalDate monday = LocalDate.of(2023, 12, 25);
        assertEquals(monday, DateCalculator.getFirstDayOfWeek(monday));

        // Wednesday -> should return Monday
        LocalDate wednesday = LocalDate.of(2023, 12, 27);
        assertEquals(monday, DateCalculator.getFirstDayOfWeek(wednesday));
    }

    @Test
    void testGetLastDayOfWeek() {
        LocalDate date = LocalDate.of(2023, 12, 25); // Monday
        LocalDate expected = LocalDate.of(2023, 12, 31); // Sunday
        assertEquals(expected, DateCalculator.getLastDayOfWeek(date));
    }

    @Test
    void testGetWeekDayName() {
        LocalDate date = LocalDate.of(2023, 12, 25); // Monday
        assertEquals("월요일", DateCalculator.getWeekDayName(date));
    }

    @Test
    void testGetEndDayOfMonth() {
        assertEquals(31, DateCalculator.getEndDayOfMonth(2023, 12));
        assertEquals(30, DateCalculator.getEndDayOfMonth(2023, 11));
        assertEquals(28, DateCalculator.getEndDayOfMonth(2023, 2));
        assertEquals(29, DateCalculator.getEndDayOfMonth(2024, 2)); // Leap year
    }

    @Test
    void testGetWeekOfMonth() {
        LocalDate firstWeek = LocalDate.of(2023, 12, 1);
        assertEquals(1, DateCalculator.getWeekOfMonth(firstWeek));

        LocalDate lastWeek = LocalDate.of(2023, 12, 31);
        assertEquals(5, DateCalculator.getWeekOfMonth(lastWeek));
    }
}