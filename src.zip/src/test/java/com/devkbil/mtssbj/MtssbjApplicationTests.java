package com.devkbil.mtssbj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtssbjApplicationTests {

    @Test
    void contextLoads() {
    }
}
